const express = require("express");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false } });
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(48).toString("hex");

if (process.env.NODE_ENV === "production" && !process.env.JWT_SECRET)
  console.warn("WARNING: set JWT_SECRET in production.");

const dataDir = path.join(__dirname, "data");
require("fs").mkdirSync(dataDir, {recursive:true});
const db = new Database(path.join(dataDir, "mtalk.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.pragma("busy_timeout = 5000");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS conversations(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user1 INTEGER NOT NULL,
 user2 INTEGER NOT NULL,
 created_at INTEGER NOT NULL,
 UNIQUE(user1,user2),
 FOREIGN KEY(user1) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(user2) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 conversation_id INTEGER NOT NULL,
 sender_id INTEGER NOT NULL,
 body TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id,id);
`);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:["'self'"],
      scriptSrc:["'self'","https://cdn.socket.io"],
      styleSrc:["'self'"],
      connectSrc:["'self","ws:","wss:"],
      imgSrc:["'self'","data:"]
    }
  }
}));
app.use(express.json({limit:"32kb"}));

const authLimiter = rateLimit({windowMs:15*60*1000,max:30,standardHeaders:true,legacyHeaders:false});
const apiLimiter = rateLimit({windowMs:60*1000,max:180,standardHeaders:true,legacyHeaders:false});
app.use("/api/", apiLimiter);

function tokenFor(user){
  return jwt.sign({sub:user.id, username:user.username}, JWT_SECRET, {expiresIn:"7d"});
}
function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Требуется вход"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch { return res.status(401).json({error:"Сессия истекла"}); }
}
function normalizePair(a,b){ return a<b ? [a,b] : [b,a]; }
function getConversation(a,b){
  const [u1,u2]=normalizePair(a,b);
  return db.prepare("SELECT * FROM conversations WHERE user1=? AND user2=?").get(u1,u2);
}
function createConversation(a,b){
  const [u1,u2]=normalizePair(a,b);
  let c=getConversation(a,b);
  if(c) return c;
  try {
    const r=db.prepare("INSERT INTO conversations(user1,user2,created_at) VALUES(?,?,?)").run(u1,u2,Date.now());
    return db.prepare("SELECT * FROM conversations WHERE id=?").get(r.lastInsertRowid);
  } catch { return getConversation(a,b); }
}
function userById(id){ return db.prepare("SELECT id,username,created_at FROM users WHERE id=?").get(id); }
function member(c,userId){ return c && (c.user1===userId || c.user2===userId); }

app.post("/api/register", authLimiter, async (req,res)=>{
  const username=String(req.body.username||"").trim();
  const password=String(req.body.password||"");
  if(!/^[A-Za-z0-9_А-Яа-яЁё-]{3,20}$/.test(username))
    return res.status(400).json({error:"Ник: 3–20 символов; буквы, цифры, _ или -"});
  if(password.length<6 || password.length>128)
    return res.status(400).json({error:"Пароль должен быть от 6 до 128 символов"});
  const exists=db.prepare("SELECT id FROM users WHERE username=?").get(username);
  if(exists) return res.status(409).json({error:"Такой ник уже занят"});
  const passwordHash=await bcrypt.hash(password,12);
  const r=db.prepare("INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)")
    .run(username,passwordHash,Date.now());
  const user=userById(r.lastInsertRowid);
  res.status(201).json({token:tokenFor(user),user});
});

app.post("/api/login", authLimiter, async (req,res)=>{
  const username=String(req.body.username||"").trim();
  const password=String(req.body.password||"");
  const u=db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if(!u || !(await bcrypt.compare(password,u.password_hash)))
    return res.status(401).json({error:"Неверный ник или пароль"});
  res.json({token:tokenFor(u),user:userById(u.id)});
});

app.get("/api/me",auth,(req,res)=>res.json({user:userById(req.user.sub)}));

app.get("/api/users",auth,(req,res)=>{
  const q=String(req.query.q||"").trim();
  if(!q) return res.json([]);
  const users=db.prepare("SELECT id,username FROM users WHERE username LIKE ? AND id<>? ORDER BY username LIMIT 20")
    .all("%"+q.replace(/[%_]/g,"\\$&")+"%",req.user.sub);
  res.json(users);
});

app.get("/api/chats",auth,(req,res)=>{
  const rows=db.prepare(`
    SELECT c.id,c.user1,c.user2,
      CASE WHEN c.user1=? THEN u2.username ELSE u1.username END AS username,
      (SELECT body FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message,
      (SELECT created_at FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_time
    FROM conversations c
    JOIN users u1 ON u1.id=c.user1 JOIN users u2 ON u2.id=c.user2
    WHERE c.user1=? OR c.user2=?
    ORDER BY COALESCE(last_time,c.created_at) DESC
  `).all(req.user.sub,req.user.sub,req.user.sub);
  res.json(rows);
});

app.post("/api/chats",auth,(req,res)=>{
  const other=Number(req.body.userId);
  if(!Number.isInteger(other)||other===req.user.sub) return res.status(400).json({error:"Неверный пользователь"});
  if(!userById(other)) return res.status(404).json({error:"Пользователь не найден"});
  const c=createConversation(req.user.sub,other);
  res.json({id:c.id, user:userById(other)});
});

app.get("/api/chats/:id/messages",auth,(req,res)=>{
  const c=db.prepare("SELECT * FROM conversations WHERE id=?").get(Number(req.params.id));
  if(!member(c,req.user.sub)) return res.status(403).json({error:"Нет доступа"});
  const rows=db.prepare(`
    SELECT m.id,m.body,m.created_at,m.sender_id,u.username
    FROM messages m JOIN users u ON u.id=m.sender_id
    WHERE m.conversation_id=? ORDER BY m.id DESC LIMIT 100
  `).all(c.id).reverse();
  res.json(rows);
});

app.use(express.static(path.join(__dirname,"public")));

io.use((socket,next)=>{
  try {
    const raw=socket.handshake.auth?.token||"";
    socket.user=jwt.verify(raw,JWT_SECRET);
    next();
  } catch { next(new Error("AUTH_FAILED")); }
});

const online=new Map();

io.on("connection",socket=>{
  const uid=Number(socket.user.sub);
  if(!online.has(uid)) online.set(uid,new Set());
  online.get(uid).add(socket.id);
  io.emit("presence",{userId:uid,online:true});

  socket.on("joinChat",chatId=>{
    const c=db.prepare("SELECT * FROM conversations WHERE id=?").get(Number(chatId));
    if(member(c,uid)) socket.join("chat:"+c.id);
  });

  socket.on("sendMessage",payload=>{
    const chatId=Number(payload?.chatId);
    const body=String(payload?.body||"").trim();
    if(!body || body.length>4000) return;
    const c=db.prepare("SELECT * FROM conversations WHERE id=?").get(chatId);
    if(!member(c,uid)) return;
    const r=db.prepare("INSERT INTO messages(conversation_id,sender_id,body,created_at) VALUES(?,?,?,?)")
      .run(chatId,uid,body,Date.now());
    const m=db.prepare(`SELECT m.id,m.body,m.created_at,m.sender_id,u.username FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?`).get(r.lastInsertRowid);
    io.to("chat:"+chatId).emit("message",m);
  });

  socket.on("disconnect",()=>{
    const set=online.get(uid); if(set){set.delete(socket.id);if(!set.size){online.delete(uid);io.emit("presence",{userId:uid,online:false});}}
  });
});

server.listen(PORT,()=>console.log(`M-Talk v2: http://localhost:${PORT}`));
